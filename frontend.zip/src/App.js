import { Routes, Route, BrowserRouter } from "react-router-dom";
import HomePage from "./pages/HomePage";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Policy from "./pages/Policy";
import Pagenotfound from "./pages/Pagenotfound";
import Register from "./pages/Auth/Register";
import { verifyToken } from "./pages/Auth/verifyToken";
import "react-toastify/dist/ReactToastify.css"
import Login from "./pages/Auth/Login";
import Dashboard from "./pages/user/Dashboard";
import PrivateRoute from "./component/Routes/Private";
import AdminRoute from "./component/Routes/AdminRoute";
import ForgotPassword from "./pages/Auth/ForgotPassword";
import AdminDashboard2 from "./pages/Admin/AdminDashboard2"



function App() {
  const { valid } = verifyToken();
  console.log(valid);
  return (
    <><BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />


        <Route path="/dashboard" element={valid ? <AdminRoute /> : <PrivateRoute />}>
          <Route path={valid ? "admin" : "user"} element={valid ? <AdminDashboard2 /> :  <Dashboard />} />
        </Route>





        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/ForgetPassword" element={<ForgotPassword />} />



        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/policy" element={<Policy />} />
        <Route path="*" element={<Pagenotfound />} />
      </Routes></BrowserRouter>
    </>
  );
}

export default App;