import React from "react";
import Layout from "../component/Layout/Layout";

const Policy = () => {
    return (
        <Layout title={"Privacy policy - Ecommerce"}>
            <div className="row contactus ">
                <div className="col-md-6 ">
                    <img
                        src="/images/contact.jpeg"
                        alt="contactus"
                        style={{ width: "100%" }}
                    />
                </div>
                <div className="col-md-4">
                    <p>add privacy policy</p>
                    <p>add privacy policy</p>
                    <p>add privacy policy</p>
                    <p>add privacy policy</p>
                    <p>add privacy policy</p>
                    <p>add privacy policy</p>
                    <p>add privacy policy</p>
                </div>
            </div>
        </Layout>
    );
};

export default Policy;