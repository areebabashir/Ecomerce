import { jwtDecode } from "jwt-decode";

export const verifyToken = () => {
  const token = localStorage.getItem("token");

  if (!token) {
    return { valid: false };
  }

  try {
    const decoded = jwtDecode(token);
    const now = Date.now() / 1000;

    if (decoded.exp < now) {
      return { valid: false };
    }

    return { valid: true };
  } catch (error) {
    return { valid: false };
  }
};