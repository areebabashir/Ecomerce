import React from 'react'

const AdminDashboard2= () => {
    return (
        <div>AdminDashboard</div>
    )
}

export default AdminDashboard2